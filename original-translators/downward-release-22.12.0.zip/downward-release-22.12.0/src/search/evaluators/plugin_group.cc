#include "../plugin.h"

namespace evaluators_plugin_group {
static PluginGroupPlugin _plugin(
    "evaluators_basic",
    "Basic Evaluators");
}
