#! /usr/bin/env python3

if __name__ == "__main__":
    from driver.main import main
    main()
